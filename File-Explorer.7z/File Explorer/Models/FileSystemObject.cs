﻿namespace FileExplorer.Models
{
    using System.IO;

    using IOPath = System.IO.Path;
    using IODetails = System.IO.File;
    using System;

    internal abstract class FileSystemObject
    {
        protected FileSystemObject(string path) : this(IOPath.GetFileNameWithoutExtension(path), path, IODetails.GetLastWriteTime(path), IOPath.GetExtension(path))
        {
        }

        protected FileSystemObject(string name, string path, DateTime lastUpdate,string fileType)
        {
            Name = name;
            Path = path;
            IsHidden = new DirectoryInfo(path).Attributes.HasFlag(FileAttributes.Hidden);
            LastUpdate = lastUpdate;
            FileType = fileType;
        }

        public string Name { get; }

        public string Path { get; }

        public bool IsHidden { get; }

        public DateTime LastUpdate { get; }

        public string FileType { get; }
    }
}