﻿namespace FileExplorer.Models
{
    internal class File : FileSystemObject
    {
        internal File(string path) : base(path)
        {
        }
    }
}