﻿namespace FileExplorer.Views
{
    public partial class FolderContentView
    {
        public FolderContentView() => InitializeComponent();
    }
}