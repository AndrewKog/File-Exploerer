﻿namespace FileExplorer.Views
{
    public partial class ShellView
    {
        public ShellView() => InitializeComponent();
    }
}