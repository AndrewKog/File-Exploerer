﻿namespace FileExplorer.Views
{
    public partial class FileSystemStructureView
    {
        public FileSystemStructureView() => InitializeComponent();
    }
}