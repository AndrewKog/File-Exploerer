﻿namespace FileExplorer.ViewModels.TreeView.Interfaces
{
    internal interface IDriveViewModel : IFolderViewModel
    {
    }
}