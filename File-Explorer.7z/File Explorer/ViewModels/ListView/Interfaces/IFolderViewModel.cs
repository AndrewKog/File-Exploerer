﻿namespace FileExplorer.ViewModels.ListView.Interfaces
{
    internal interface IFolderViewModel : IFileSystemObjectViewModel
    {
    }
}