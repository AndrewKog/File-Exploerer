﻿namespace FileExplorer.ViewModels.ListView.Interfaces
{
    internal interface IFileViewModel : IFileSystemObjectViewModel
    {
    }
}