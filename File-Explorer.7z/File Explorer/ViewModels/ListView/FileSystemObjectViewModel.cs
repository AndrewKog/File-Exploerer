﻿namespace FileExplorer.ViewModels.ListView
{
    using FileExplorer.Models;
    using FileExplorer.ViewModels.ListView.Interfaces;
    using System;

    internal abstract class FileSystemObjectViewModel : ViewModelBase, IFileSystemObjectViewModel
    {
        public abstract FileSystemObject Model { get; set; }

        public override string DisplayName => Model.Name;
        public  DateTime DisplayDetails => Model.LastUpdate;

        public string FileType => Model.FileType;

        public abstract void DoubleClick();
    }
}