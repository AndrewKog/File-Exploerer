﻿namespace FileExplorer.ViewModels
{
    using Caliburn.Micro;

    using FileExplorer.ViewModels.Interfaces;

    internal abstract class ViewModelBase : Screen, IViewModelBase
    {
    }
}