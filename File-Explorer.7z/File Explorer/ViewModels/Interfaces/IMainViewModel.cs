﻿namespace FileExplorer.ViewModels.Interfaces
{
    internal interface IMainViewModel : IViewModelBase
    {
    }
}