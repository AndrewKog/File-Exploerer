﻿namespace FileExplorer.ViewModels.Interfaces
{
    using Caliburn.Micro;

    internal interface IViewModelBase : IViewAware, IScreen, IChild
    {
    }
}