﻿namespace FileExplorer.ViewModels.Interfaces
{
    internal interface IFolderContentViewModel : IViewModelBase
    {
    }
}