﻿namespace FileExplorer.ViewModels.Interfaces
{
    internal interface IFileSystemStructureViewModel : IViewModelBase
    {
    }
}