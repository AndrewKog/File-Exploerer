# File Explorer
A C# WPF application, representing a conventional Windows file system explorer. Allows the traversal of inaccessible file systems.

Current Preview:

![File Explorer Current State](/Preview/File%20Explorer%20Current%20State.png)